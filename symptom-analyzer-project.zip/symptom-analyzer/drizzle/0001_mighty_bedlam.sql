CREATE TABLE `analyses` (
	`id` varchar(64) NOT NULL,
	`userId` varchar(64) NOT NULL,
	`symptoms` text NOT NULL,
	`age` varchar(20),
	`gender` varchar(20),
	`medicalHistory` text,
	`analysis` text NOT NULL,
	`suggestedTests` text NOT NULL,
	`urgencyLevel` varchar(20) NOT NULL,
	`createdAt` timestamp DEFAULT (now()),
	CONSTRAINT `analyses_id` PRIMARY KEY(`id`)
);
