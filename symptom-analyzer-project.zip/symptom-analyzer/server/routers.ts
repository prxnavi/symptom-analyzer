import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Symptom analysis router
  symptomAnalyzer: router({
    analyze: protectedProcedure
      .input(
        z.object({
          symptoms: z.string().min(1, "Symptoms are required"),
          age: z.string().optional(),
          gender: z.string().optional(),
          medicalHistory: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { invokeLLM } = await import("./_core/llm");
        const { createAnalysis } = await import("./db");
        const { randomUUID } = await import("crypto");

        // Construct the prompt for AI analysis
        const prompt = `You are a medical AI assistant. Analyze the following patient information and provide:
1. A detailed analysis of the symptoms
2. Possible conditions or diagnoses (with disclaimer that this is not a substitute for professional medical advice)
3. Recommended diagnostic tests
4. Urgency level (Low, Medium, High, Emergency)

Patient Information:
- Symptoms: ${input.symptoms}
${input.age ? `- Age: ${input.age}` : ""}
${input.gender ? `- Gender: ${input.gender}` : ""}
${input.medicalHistory ? `- Medical History: ${input.medicalHistory}` : ""}

Provide your response in JSON format with the following structure:
{
  "analysis": "detailed analysis text",
  "possibleConditions": ["condition1", "condition2"],
  "suggestedTests": ["test1", "test2"],
  "urgencyLevel": "Low|Medium|High|Emergency",
  "disclaimer": "medical disclaimer text"
}`;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content:
                "You are a medical AI assistant. Always include appropriate medical disclaimers.",
            },
            { role: "user", content: prompt },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "symptom_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  analysis: {
                    type: "string",
                    description: "Detailed analysis of the symptoms",
                  },
                  possibleConditions: {
                    type: "array",
                    items: { type: "string" },
                    description: "List of possible conditions",
                  },
                  suggestedTests: {
                    type: "array",
                    items: { type: "string" },
                    description: "List of recommended diagnostic tests",
                  },
                  urgencyLevel: {
                    type: "string",
                    enum: ["Low", "Medium", "High", "Emergency"],
                    description: "Urgency level of the condition",
                  },
                  disclaimer: {
                    type: "string",
                    description: "Medical disclaimer",
                  },
                },
                required: [
                  "analysis",
                  "possibleConditions",
                  "suggestedTests",
                  "urgencyLevel",
                  "disclaimer",
                ],
                additionalProperties: false,
              },
            },
          },
        });

        const content = typeof response.choices[0].message.content === 'string' 
          ? response.choices[0].message.content 
          : JSON.stringify(response.choices[0].message.content);
        const result = JSON.parse(content || "{}");

        // Save to database
        const analysisId = randomUUID();
        await createAnalysis({
          id: analysisId,
          userId: ctx.user.id,
          symptoms: input.symptoms,
          age: input.age,
          gender: input.gender,
          medicalHistory: input.medicalHistory,
          analysis: JSON.stringify({
            analysis: result.analysis,
            possibleConditions: result.possibleConditions,
            disclaimer: result.disclaimer,
          }),
          suggestedTests: JSON.stringify(result.suggestedTests),
          urgencyLevel: result.urgencyLevel,
        });

        return {
          id: analysisId,
          ...result,
        };
      }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      const { getUserAnalyses } = await import("./db");
      return getUserAnalyses(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.string() }))
      .query(async ({ input }) => {
        const { getAnalysisById } = await import("./db");
        return getAnalysisById(input.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
