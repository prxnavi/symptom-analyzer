import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Calendar, Activity } from "lucide-react";
import { format } from "date-fns";

export default function History() {
  const { data: analyses, isLoading } = trpc.symptomAnalyzer.getHistory.useQuery();

  const getUrgencyVariant = (level: string) => {
    switch (level) {
      case "Emergency":
        return "destructive";
      case "High":
        return "destructive";
      case "Medium":
        return "default";
      case "Low":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Analysis History</h1>
          <p className="text-gray-600">View your previous symptom analyses</p>
        </div>

        {isLoading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
          </div>
        )}

        {!isLoading && analyses && analyses.length === 0 && (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-12 text-gray-500">
                <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No analysis history yet</p>
                <p className="text-sm mt-2">Start by analyzing your symptoms</p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-4">
          {analyses?.map((analysis) => {
            let parsedAnalysis;
            try {
              parsedAnalysis = JSON.parse(analysis.analysis);
            } catch {
              parsedAnalysis = { analysis: analysis.analysis };
            }

            let suggestedTests;
            try {
              suggestedTests = JSON.parse(analysis.suggestedTests);
            } catch {
              suggestedTests = [];
            }

            return (
              <Card key={analysis.id} className="shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">
                        {analysis.symptoms.substring(0, 100)}
                        {analysis.symptoms.length > 100 ? "..." : ""}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-2 mt-2">
                        <Calendar className="h-4 w-4" />
                        {analysis.createdAt
                          ? format(new Date(analysis.createdAt), "PPP 'at' p")
                          : "Unknown date"}
                      </CardDescription>
                    </div>
                    <Badge variant={getUrgencyVariant(analysis.urgencyLevel)}>
                      {analysis.urgencyLevel}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-gray-700 mb-2">Analysis</h4>
                    <p className="text-sm text-gray-600 line-clamp-3">
                      {parsedAnalysis.analysis}
                    </p>
                  </div>

                  {parsedAnalysis.possibleConditions && (
                    <div>
                      <h4 className="font-semibold text-sm text-gray-700 mb-2">
                        Possible Conditions
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {parsedAnalysis.possibleConditions.map(
                          (condition: string, index: number) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {condition}
                            </Badge>
                          )
                        )}
                      </div>
                    </div>
                  )}

                  {suggestedTests.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm text-gray-700 mb-2">
                        Suggested Tests ({suggestedTests.length})
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {suggestedTests.slice(0, 3).map((test: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {test}
                          </Badge>
                        ))}
                        {suggestedTests.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{suggestedTests.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

