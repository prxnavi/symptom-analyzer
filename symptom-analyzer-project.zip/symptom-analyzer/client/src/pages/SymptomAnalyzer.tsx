import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, AlertCircle, CheckCircle2, Activity } from "lucide-react";
import { toast } from "sonner";

export default function SymptomAnalyzer() {
  const [symptoms, setSymptoms] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [medicalHistory, setMedicalHistory] = useState("");
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  const analyzeMutation = trpc.symptomAnalyzer.analyze.useMutation({
    onSuccess: (data) => {
      setAnalysisResult(data);
      toast.success("Analysis completed successfully");
    },
    onError: (error) => {
      toast.error("Failed to analyze symptoms: " + error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!symptoms.trim()) {
      toast.error("Please describe your symptoms");
      return;
    }
    analyzeMutation.mutate({
      symptoms,
      age: age || undefined,
      gender: gender || undefined,
      medicalHistory: medicalHistory || undefined,
    });
  };

  const getUrgencyColor = (level: string) => {
    switch (level) {
      case "Emergency":
        return "text-red-600 bg-red-50 border-red-200";
      case "High":
        return "text-orange-600 bg-orange-50 border-orange-200";
      case "Medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200";
      case "Low":
        return "text-green-600 bg-green-50 border-green-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const getUrgencyIcon = (level: string) => {
    switch (level) {
      case "Emergency":
      case "High":
        return <AlertCircle className="h-5 w-5" />;
      case "Medium":
        return <Activity className="h-5 w-5" />;
      case "Low":
        return <CheckCircle2 className="h-5 w-5" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">AI Patient Symptom Analyzer</h1>
          <p className="text-gray-600">
            Describe your symptoms and get AI-powered analysis with diagnostic test recommendations
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Input Form */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Enter Your Information</CardTitle>
              <CardDescription>
                Provide as much detail as possible for accurate analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="symptoms">Symptoms *</Label>
                  <Textarea
                    id="symptoms"
                    placeholder="Describe your symptoms in detail (e.g., headache for 3 days, fever, nausea...)"
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    rows={5}
                    className="resize-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="text"
                      placeholder="e.g., 35"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <Select value={gender} onValueChange={setGender}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Male">Male</SelectItem>
                        <SelectItem value="Female">Female</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                        <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="medicalHistory">Medical History (Optional)</Label>
                  <Textarea
                    id="medicalHistory"
                    placeholder="Any relevant medical conditions, allergies, or medications..."
                    value={medicalHistory}
                    onChange={(e) => setMedicalHistory(e.target.value)}
                    rows={3}
                    className="resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={analyzeMutation.isPending}
                >
                  {analyzeMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    "Analyze Symptoms"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Results Display */}
          <div className="space-y-4">
            {analyzeMutation.isPending && (
              <Card className="shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-center py-12">
                    <div className="text-center">
                      <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
                      <p className="text-gray-600">Analyzing your symptoms...</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {analysisResult && !analyzeMutation.isPending && (
              <>
                {/* Urgency Level */}
                <Alert className={`border-2 ${getUrgencyColor(analysisResult.urgencyLevel)}`}>
                  <div className="flex items-center gap-2">
                    {getUrgencyIcon(analysisResult.urgencyLevel)}
                    <AlertDescription className="font-semibold">
                      Urgency Level: {analysisResult.urgencyLevel}
                    </AlertDescription>
                  </div>
                </Alert>

                {/* Analysis */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle>Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 whitespace-pre-line">{analysisResult.analysis}</p>
                  </CardContent>
                </Card>

                {/* Possible Conditions */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle>Possible Conditions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {analysisResult.possibleConditions.map((condition: string, index: number) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-blue-600 mt-1">•</span>
                          <span className="text-gray-700">{condition}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Suggested Tests */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle>Recommended Diagnostic Tests</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {analysisResult.suggestedTests.map((test: string, index: number) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-green-600 mt-1">✓</span>
                          <span className="text-gray-700">{test}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Disclaimer */}
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    {analysisResult.disclaimer}
                  </AlertDescription>
                </Alert>
              </>
            )}

            {!analysisResult && !analyzeMutation.isPending && (
              <Card className="shadow-lg">
                <CardContent className="pt-6">
                  <div className="text-center py-12 text-gray-500">
                    <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Enter your symptoms to get started</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

